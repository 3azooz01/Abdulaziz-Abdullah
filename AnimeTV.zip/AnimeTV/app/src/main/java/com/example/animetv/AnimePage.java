package com.example.animetv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_page);

        Bundle b = getIntent().getExtras();
        Anime a = (Anime)b.getSerializable("Anime");
        final String websiteClick = a.getWebsite();
        final String websiteClick2 = a.getWebsite2();

        ImageView img = findViewById(R.id.picanime);
        TextView title = findViewById(R.id.titleTxt2);
        TextView web1 = findViewById(R.id.websiteTxt);
        TextView web2 = findViewById(R.id.websiteTxt2);
        TextView ep = findViewById(R.id.epTxt);
        TextView since = findViewById(R.id.sinceTxt);


                web1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse(websiteClick);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
                web2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse(websiteClick2);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        img.setImageResource(a.getImage());
        title.setText(a.getName());
        ep.setText("Episodes: " + a.getEpisodes());
        since.setText("Release: " + a.getRelease());






    }
}