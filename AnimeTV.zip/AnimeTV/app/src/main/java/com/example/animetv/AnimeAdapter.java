package com.example.animetv;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class AnimeAdapter extends RecyclerView.Adapter {

    ArrayList<Anime> aArray;
    Context context;

    public AnimeAdapter(ArrayList<Anime> aArray, Context context) {
        this.aArray = aArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.animerv, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).img.setImageResource(aArray.get(position).getImage());
        ((ViewHolder) holder).title.setText(aArray.get(position).getName());
        ((ViewHolder) holder).release.setText(aArray.get(position).getRelease()+"");
        ((ViewHolder) holder).completion.setText(aArray.get(position).getCompletion());
        ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, AnimePage.class);
                i.putExtra ("Anime",aArray.get(position));
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return aArray.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView img;
        public ImageView done;
        public TextView title;
        public TextView release;
        public TextView completion;
        public View view;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        view = itemView;
        img = itemView.findViewById(R.id.animeImg);
        done = itemView.findViewById(R.id.doneImg);
        title = itemView.findViewById(R.id.titleTxt);
        release = itemView.findViewById(R.id.releaseTxt);
        completion = itemView.findViewById(R.id.completionTxt);


    }
}
}
