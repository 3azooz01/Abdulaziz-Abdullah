package com.example.animetv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.security.acl.AclNotFoundException;
import java.util.ArrayList;

public class AnimeList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_list);

        ArrayList<Anime> myAnime = new ArrayList<>();

        Anime BlackClover = new Anime("Black Clover", "https://www12.9anime.to/watch/black-clover.v2k6/ep-1", "https://twist.moe/a/black-clover-tv/1", R.drawable.blackclover, 2017, 154, "Ongoing");
        Anime FMAB = new Anime("Full Metal Alchemist Brotherhood", "https://www12.9anime.to/watch/fullmetal-alchemist-brotherhood.0r7", "https://twist.moe/a/fullmetal-alchemist-brotherhood/1", R.drawable.fmabpic, 2009, 64, "Completed");
        Anime HXH = new Anime("Hunter X Hunter","https://www12.9anime.to/watch/hunter-x-hunter.295/ep-1" ,"https://twist.moe/a/hunter-x-hunter-2011/1" ,R.drawable.hxhpic, 2011, 148, "Completed");
        Anime Naruto = new Anime("Naruto", "https://www12.9anime.to/watch/naruto.xx8z/ep-1", "https://twist.moe/a/naruto/1", R.drawable.narutopic, 2002, 220, "Completed");
        Anime NarutoShippuden = new Anime("Naruto Shippuden", "https://www12.9anime.to/watch/naruto-shippuden.qv3","https://twist.moe/a/naruto-shippuuden/1" ,R.drawable.narutoshippic, 2007, 500, "Completed");
        Anime OnePiece = new Anime("One Piece", "https://www12.9anime.to/watch/one-piece.ov8/ep-1", "https://twist.moe/a/one-piece/1",R.drawable.onepiecepic2, 1999, 947, "Ongoing");

        myAnime.add(BlackClover);
        myAnime.add(FMAB);
        myAnime.add(HXH);
        myAnime.add(Naruto);
        myAnime.add(NarutoShippuden);
        myAnime.add(OnePiece);




        RecyclerView rv = findViewById(R.id.recyclerview);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lay = new LinearLayoutManager(this);
        rv.setLayoutManager(lay);

        AnimeAdapter aa = new AnimeAdapter(myAnime, this);
        rv.setAdapter(aa);

    }
}