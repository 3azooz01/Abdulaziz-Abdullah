package com.example.animetv;

import java.io.Serializable;

public class Anime implements Serializable {
    private String name;
    private String website;
    private String website2;
    private int image;
    private int release;
    private int episodes;
    private String completion;


    public Anime(String name, String website, String website2, int image, int release, int episodes, String completion) {
        this.name = name;
        this.website = website;
        this.website2 = website2;
        this.image = image;
        this.release = release;
        this.episodes = episodes;
        this.completion = completion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getWebsite2() {
        return website2;
    }

    public void setWebsite2(String website2) {
        this.website2 = website2;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getRelease() {
        return release;
    }

    public void setRelease(int release) {
        this.release = release;
    }

    public int getEpisodes() {
        return episodes;
    }

    public void setEpisodes(int episodes) {
        this.episodes = episodes;
    }

    public String getCompletion() {
        return completion;
    }

    public void setCompletion(String completion) {
        this.completion = completion;
    }
}
